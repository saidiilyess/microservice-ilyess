package tn.esprit.tpfoyer.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tn.esprit.tpfoyer.models.Assignment;
import tn.esprit.tpfoyer.models.Course;
import tn.esprit.tpfoyer.services.AssignmentService;
import tn.esprit.tpfoyer.services.CourseService;

import java.util.List;

@RestController
@RequestMapping("/api/assignments")
public class AssignmentController {

    @Autowired
    private AssignmentService assignmentService;

    @Autowired
    private CourseService courseService; // Add @Autowired to inject the CourseService instance

    // Example in AssignmentController
    @PostMapping("/create")
    public ResponseEntity<Assignment> createAssignment(@RequestBody Assignment assignment) {
        if (assignment.getCourse() == null || assignment.getCourse().getId() == null) {
            return ResponseEntity.badRequest().body(null);
        }

        // Save the assignment
        Assignment savedAssignment = assignmentService.saveAssignment(assignment);
        return ResponseEntity.ok(savedAssignment);
    }


    @GetMapping("/course/{courseId}")
    public ResponseEntity<List<Assignment>> getAssignmentsByCourse(@PathVariable Long courseId) {
        Course course = new Course();
        course.setId(courseId);
        return ResponseEntity.ok(assignmentService.getAssignmentsByCourse(course));
    }
}
