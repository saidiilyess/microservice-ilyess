package tn.esprit.tpfoyer.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import tn.esprit.tpfoyer.models.Project;
import tn.esprit.tpfoyer.repositories.ProjectRepository;

import java.util.Optional;

@Service
public class ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    /**
     * ✅ Search & Sort projects with pagination
     */
    public Page<Project> searchAndSortProjects(String search, Pageable pageable) {
        return projectRepository.findByNameContainingIgnoreCase(search, pageable);
    }

    /**
     * ✅ Get project by ID
     */
    public Optional<Project> getProjectById(Long id) {
        return projectRepository.findById(id);
    }

    /**
     * ✅ Save or update a project
     */
    public Project saveProject(Project project) {
        return projectRepository.save(project);
    }

    /**
     * ✅ Update a project
     */
    public Project updateProject(Long id, Project projectDetails) {
        Optional<Project> existingProject = projectRepository.findById(id);
        if (existingProject.isPresent()) {
            Project project = existingProject.get();
            project.setName(projectDetails.getName());
            project.setLocation(projectDetails.getLocation());
            project.setStatus(projectDetails.getStatus());
            project.setStartDate(projectDetails.getStartDate());
            project.setEndDate(projectDetails.getEndDate());
            return projectRepository.save(project);
        } else {
            throw new RuntimeException("Project not found with id " + id);
        }
    }

    /**
     * ✅ Delete a project
     */
    public void deleteProject(Long id) {
        projectRepository.deleteById(id);
    }
}
